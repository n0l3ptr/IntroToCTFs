Could you test our echo server?

nc fsu-ctf.selfip.net 9998
