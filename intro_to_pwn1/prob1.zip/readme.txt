nc fsu-ctf.selfip.net 9996

